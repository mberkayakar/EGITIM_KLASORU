SET DEFINE OFF;
Insert into MUDURLUK_HEDEF
   (MUDURLUK_ADI, MUSTERI_SAYISI, MUSTERI_HEDEFI)
 Values
   ('Adana Ceyhan', 180, 200);
Insert into MUDURLUK_HEDEF
   (MUDURLUK_ADI, MUSTERI_SAYISI, MUSTERI_HEDEFI)
 Values
   ('Konya Sel�uklu', 3580, 4000);
Insert into MUDURLUK_HEDEF
   (MUDURLUK_ADI, MUSTERI_SAYISI, MUSTERI_HEDEFI)
 Values
   ('Ankara �ankaya', 7660, 7750);
Insert into MUDURLUK_HEDEF
   (MUDURLUK_ADI, MUSTERI_SAYISI, MUSTERI_HEDEFI)
 Values
   ('�stanbul Ata�ehir', 8650, 8650);
Insert into MUDURLUK_HEDEF
   (MUDURLUK_ADI, MUSTERI_SAYISI, MUSTERI_HEDEFI)
 Values
   ('�zmir Bornova', 565, 600);
Insert into MUDURLUK_HEDEF
   (MUDURLUK_ADI, MUSTERI_SAYISI, MUSTERI_HEDEFI)
 Values
   ('Karab�k Safranbolu', 300, 300);
COMMIT;
