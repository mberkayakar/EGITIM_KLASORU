SET DEFINE OFF;
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (1, 'ADANA', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (2, 'ADIYAMAN', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (3, 'AFYON', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (4, 'A�RI', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (5, 'AMASYA', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (6, 'ANKARA', 1);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (7, 'ANTALYA', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (8, 'ARTV�N', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (9, 'AYDIN', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (10, 'BALIKESIR', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (11, 'B�LEC�K', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (12, 'B�NG�L', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (13, 'B�TL�S', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (14, 'BOLU', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (15, 'BURDUR', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (16, 'BURSA', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (17, '�ANAKKALE', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (18, '�ANKIRI', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (19, '�ORUM', 1);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (20, 'DEN�ZL�', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (21, 'D�YARBAKIR', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (22, 'ED�RNE', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (23, 'ELAZI�', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (24, 'ERZ�NCAN', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (25, 'ERZURUM', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (26, 'ESK��EH�R', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (27, 'GAZ�ANTEP', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (28, 'GIRESUN', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (29, 'G�M�SHANE', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (30, 'HAKKARI', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (31, 'HATAY', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (32, 'ISPARTA', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (33, 'MERSIN', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (34, 'ISTANBUL-AND', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (35, 'IZMIR', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (36, 'KARS', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (37, 'KASTAMONU', 1);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (38, 'KAYSERI', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (39, 'KIRKLARELI', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (40, 'KIRSEHIR', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (41, 'KOCAELI', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (42, 'KONYA', 1);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (43, 'K�TAHYA', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (44, 'MALATYA', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (45, 'MANISA', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (46, 'KAHRAMANMARAS', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (47, 'MARDIN', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (48, 'MUGLA', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (49, 'MUS', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (50, 'NEVSEHIR', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (51, 'NIGDE', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (52, 'ORDU', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (53, 'RIZE', 1);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (54, 'SAKARYA', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (55, 'SAMSUN', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (56, 'SIIRT', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (57, 'SINOP', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (58, 'SIVAS', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (59, 'TEKIRDAG', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (60, 'TOKAT', 1);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (61, 'TRABZON', 1);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (62, 'TUNCELI', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (63, 'SANLIURFA', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (64, 'USAK', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (65, 'VAN', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (66, 'YOZGAT', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (67, 'ZONGULDAK', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (68, 'AKSARAY', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (69, 'BAYBURT', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (70, 'KARAMAN', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (71, 'KIRIKKALE', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (72, 'BATMAN', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (73, 'SIRNAK', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (74, 'BARTIN', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (75, 'ARDAHAN', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (76, 'IGDIR', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (77, 'YALOVA', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (78, 'KARAB�K', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (79, 'K�L�S', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (80, 'OSMANIYE', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (81, 'D�ZCE', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (234, 'ISTANBUL-AVR', 2);
COMMIT;
