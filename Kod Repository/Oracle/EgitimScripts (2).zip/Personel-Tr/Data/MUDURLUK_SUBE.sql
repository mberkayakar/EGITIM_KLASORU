SET DEFINE OFF;
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (67, 9, 'Hakkari 9. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (67, 6, 'Hakkari 1116. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (67, 7, 'Hakkari 7. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (67, 8, 'Hakkari 8. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (71, 12, 'Isparta 12. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (71, 15, 'Isparta 15. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (71, 13, 'Isparta 13. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (72, 16, 'Isparta 16. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (135, 18, 'Mersin (��el) 18. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (135, 19, 'Mersin (��el) 19. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (135, 20, 'Mersin (��el) 20. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (3262, 10, 'Hatay 10. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (3263, 11, 'Hatay 11. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (3266, 14, 'Hatay 14. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (3273, 17, 'Isparta 17. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (4551, 3, 'Giresun 3. �ube');
COMMIT;
