SET DEFINE OFF;
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (1, 'Y�ll�k �zin');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (2, 'Saatlik �zin');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (3, 'Do�um G�n� �zni');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (4, 'Mazeret �zni');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (5, 'Evlilik �zni');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (6, 'Vefat �zni');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (7, 'Do�um �zni');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (8, 'Do�al Afet �zni');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (9, 'Babal�k �zni');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (10, 'Ta��nma �zni');
COMMIT;
