SET DEFINE OFF;
Insert into BOLGELER
   (BOLGE_KODU, BOLGE_ADI)
 Values
   (1, '�� ANADOLU');
Insert into BOLGELER
   (BOLGE_KODU, BOLGE_ADI)
 Values
   (2, 'MARMARA');
Insert into BOLGELER
   (BOLGE_KODU, BOLGE_ADI)
 Values
   (3, 'EGE');
Insert into BOLGELER
   (BOLGE_KODU, BOLGE_ADI)
 Values
   (4, 'AKDEN�Z');
Insert into BOLGELER
   (BOLGE_KODU, BOLGE_ADI)
 Values
   (5, 'DO�U ANADALU');
Insert into BOLGELER
   (BOLGE_KODU, BOLGE_ADI)
 Values
   (6, 'G�NEY DO�U ANADOLU');
Insert into BOLGELER
   (BOLGE_KODU, BOLGE_ADI)
 Values
   (7, 'KARADEN�Z');
COMMIT;

SET DEFINE OFF;
Insert into CEZA_BILGI
   (PERSONEL_ID, CEZA_ACIKLAMA, BASLANGIC_TARIHI, BITIS_TARIHI)
 Values
   (5016, 'Uzakla�t�rma', TO_DATE('09/20/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/21/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into CEZA_BILGI
   (PERSONEL_ID, CEZA_ACIKLAMA, BASLANGIC_TARIHI, BITIS_TARIHI)
 Values
   (5037, 'Y�z K�zart�c�', TO_DATE('06/15/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('06/20/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into CEZA_BILGI
   (PERSONEL_ID, CEZA_ACIKLAMA, BASLANGIC_TARIHI, BITIS_TARIHI)
 Values
   (5029, 'Disiplin', TO_DATE('07/30/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/02/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
COMMIT;

SET DEFINE OFF;
Insert into DEPARTMAN
   (DEPT_ID, DEPT_ISMI)
 Values
   (100, 'BT Finansal Uygulamalar Direkt�rl���');
Insert into DEPARTMAN
   (DEPT_ID, DEPT_ISMI)
 Values
   (101, 'BT M��teri Uygulamalar� Direkt�rl���');
Insert into DEPARTMAN
   (DEPT_ID, DEPT_ISMI)
 Values
   (102, 'BT Operasyon Direkt�rl���');
Insert into DEPARTMAN
   (DEPT_ID, DEPT_ISMI)
 Values
   (103, '�r�n ve Servis Geli�tirme Direkt�rl���');
Insert into DEPARTMAN
   (DEPT_ID, DEPT_ISMI)
 Values
   (104, 'G�venlik Direkt�rl���');
Insert into DEPARTMAN
   (DEPT_ID, DEPT_ISMI)
 Values
   (105, 'Proje Y�netim Ofisi Direkt�rl���');
Insert into DEPARTMAN
   (DEPT_ID, DEPT_ISMI)
 Values
   (106, 'Ses Tahakkuk ve Faturalama M�d�rl���');
Insert into DEPARTMAN
   (DEPT_ID, DEPT_ISMI)
 Values
   (107, 'Veri Tahakkuk ve Faturalama M�d�rl���');
Insert into DEPARTMAN
   (DEPT_ID, DEPT_ISMI)
 Values
   (108, 'Tahsilat ve Mediation M�d�rl���');
Insert into DEPARTMAN
   (DEPT_ID, DEPT_ISMI)
 Values
   (109, 'Ses CRM M�d�rl���');
Insert into DEPARTMAN
   (DEPT_ID, DEPT_ISMI)
 Values
   (110, 'Data CRM M�d�rl���');
Insert into DEPARTMAN
   (DEPT_ID, DEPT_ISMI)
 Values
   (111, '�� Zekas� M�d�rl���');
Insert into DEPARTMAN
   (DEPT_ID, DEPT_ISMI)
 Values
   (112, 'Kaynak ve Envanter M�d�rl���');
Insert into DEPARTMAN
   (DEPT_ID, DEPT_ISMI)
 Values
   (113, 'Operasyonel Raporlama M�d�rl���');
Insert into DEPARTMAN
   (DEPT_ID, DEPT_ISMI)
 Values
   (114, 'Kurumsal Uygulamalar M�d�rl���');
COMMIT;

SET DEFINE OFF;
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (1, 'ADANA', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (2, 'ADIYAMAN', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (3, 'AFYON', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (4, 'A�RI', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (5, 'AMASYA', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (6, 'ANKARA', 1);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (7, 'ANTALYA', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (8, 'ARTV�N', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (9, 'AYDIN', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (10, 'BALIKESIR', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (11, 'B�LEC�K', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (12, 'B�NG�L', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (13, 'B�TL�S', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (14, 'BOLU', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (15, 'BURDUR', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (16, 'BURSA', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (17, '�ANAKKALE', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (18, '�ANKIRI', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (19, '�ORUM', 1);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (20, 'DEN�ZL�', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (21, 'D�YARBAKIR', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (22, 'ED�RNE', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (23, 'ELAZI�', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (24, 'ERZ�NCAN', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (25, 'ERZURUM', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (26, 'ESK��EH�R', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (27, 'GAZ�ANTEP', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (28, 'GIRESUN', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (29, 'G�M�SHANE', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (30, 'HAKKARI', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (31, 'HATAY', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (32, 'ISPARTA', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (33, 'MERSIN', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (34, 'ISTANBUL-AND', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (35, 'IZMIR', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (36, 'KARS', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (37, 'KASTAMONU', 1);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (38, 'KAYSERI', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (39, 'KIRKLARELI', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (40, 'KIRSEHIR', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (41, 'KOCAELI', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (42, 'KONYA', 1);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (43, 'K�TAHYA', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (44, 'MALATYA', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (45, 'MANISA', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (46, 'KAHRAMANMARAS', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (47, 'MARDIN', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (48, 'MUGLA', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (49, 'MUS', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (50, 'NEVSEHIR', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (51, 'NIGDE', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (52, 'ORDU', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (53, 'RIZE', 1);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (54, 'SAKARYA', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (55, 'SAMSUN', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (56, 'SIIRT', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (57, 'SINOP', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (58, 'SIVAS', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (59, 'TEKIRDAG', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (60, 'TOKAT', 1);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (61, 'TRABZON', 1);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (62, 'TUNCELI', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (63, 'SANLIURFA', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (64, 'USAK', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (65, 'VAN', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (66, 'YOZGAT', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (67, 'ZONGULDAK', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (68, 'AKSARAY', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (69, 'BAYBURT', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (70, 'KARAMAN', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (71, 'KIRIKKALE', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (72, 'BATMAN', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (73, 'SIRNAK', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (74, 'BARTIN', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (75, 'ARDAHAN', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (76, 'IGDIR', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (77, 'YALOVA', 2);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (78, 'KARAB�K', 4);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (79, 'K�L�S', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (80, 'OSMANIYE', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (81, 'D�ZCE', 3);
Insert into ILLER
   (IL_KODU, IL_ADI, BOLGE_KODU)
 Values
   (234, 'ISTANBUL-AVR', 2);
COMMIT;

SET DEFINE OFF;
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (1, 'Y�ll�k �zin');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (2, 'Saatlik �zin');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (3, 'Do�um G�n� �zni');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (4, 'Mazeret �zni');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (5, 'Evlilik �zni');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (6, 'Vefat �zni');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (7, 'Do�um �zni');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (8, 'Do�al Afet �zni');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (9, 'Babal�k �zni');
Insert into IZIN_TURLERI
   (IZIN_TURU, ACIKLAMA)
 Values
   (10, 'Ta��nma �zni');
COMMIT;

SET DEFINE OFF;
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (1, 'Ankara - Ayd�nl�kevler', 6);
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (2, 'Ankara - TOBB Yerle�kesi', 6);
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (3, 'Ankara - Akademi E�itim Birimi', 6);
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (4, 'Akara - �l M�d�rl���', 6);
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (5, '�stanbul - �mraniye', 34);
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (6, '�stanbul - Ac�badem', 34);
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (7, '�stanbul - Gayrettepe', 34);
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (8, 'Trabzon - Ma�ka', 61);
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (9, 'Konya - Sel�uklu', 42);
COMMIT;

SET DEFINE OFF;
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (2522, 'SAMSUN', '�L SANTRALLER M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (10003, 'ISPARTA', 'OPERASYON M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (10057, 'MAN�SA', 'HUKUK ��LER� M�D.');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8061, 'MAN�SA', 'B�LG� ��LEM MUD');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4982, 'MAN�SA', 'MAN�SA');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4756, 'U�AK', 'MUHASEBE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3504, 'D�YARBAKIR', 'B�SM�L ��LETME �EFL���55');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3563, '�STANBUL AVR.', 'GEL�RLER TAK�P M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3988, '�STANBUL AVR.', 'F�BER OPT�K KABLO M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (10208, '�STANBUL AVR.', 'HUKUK ��LER� M�D');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6547, '�STANBUL AVR.', 'MUHASEBE M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (9376, '�STANBUL AVR.', 'KURUMSAL SATI�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (10526, '�STANBUL(AVRUPA)', 'TOPTAN SATI�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (9787, '�STANBUL(AVRUPA)', 'KURUMSAK G�VENL�K H�ZMETLER�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5024, 'ESK��EH�R', 'B�LG� ��LEM M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4755, 'ESK��EH�R', 'KAMBS');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (9147, 'BURSA', 'BAY�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4526, 'BURSA', 'KURUMSAL SATI� M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (10185, '�ZM�R', 'ER���M OPERASYON');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7334, '�ZM�R', '�ZM�R TRANSM�SYON');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (10514, 'ERZURUM', 'B�LG� ��LEM M�D.');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (10179, 'ERZURUM', 'MAK.ENJ.SO�.S�S.M�D');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7134, 'ERZURUM', '�L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3902, 'ED�RNE', 'F�NANS&TEDAR�K Z�NC�R� UZM.');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8574, 'ED�RNE', 'HUKUK UZMANLI�I');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4121, 'ED�RNE', '�L Y�NET�C�LER�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7474, 'KIRKLAREL�', 'B�LG� ��LEM');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (9851, 'HAKKAR�', 'MUHASEBE M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6109, 'ANKARA', 'HUKUK');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (11450, 'MERS�N (��EL)', 'HUKUK ��LER� M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8115, 'S�VAS', 'B�LG� ��LEM');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (10232, 'S�VAS', 'S�VAS');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (12469, 'TOKAT', 'TOKAT �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8831, 'TOKAT', 'MUHASEBE M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (12014, 'ORDU', 'HUKUK UZMANLI�I');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (11740, 'SAMSUN', 'HUKUK M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4870, 'ZONGULDAK', 'F�NANS TEDAR�K Z�NC�R�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (10851, 'KIRKLAREL�', 'HUKUK M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6742, 'KIRKLAREL�', 'F�NANS VE TEDAR�K Z�NC�R� UZMA');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (9013, 'KONYA', 'M�M M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (9060, 'KONYA', 'MUHASEBE M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (13009, 'MALATYA', 'B�LG� ��LEM M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (10042, 'ORDU', 'MUHASEBE M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (10059, 'G�RESUN', 'F�NANS&TEDAR�K Z�NC�R� UZMANLI');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (9063, 'G�RESUN', 'HUKUK ��LER� UZMANLI�I');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (11308, 'TRABZON', 'HUKUK M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (9941, 'MU�LA', '�L_SANTRALLER_M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (9578, 'MU�LA', '�L_ER���M �EBEKELER� M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6592, 'MU�LA', '�L_TRANSM�SYON_M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7807, 'MU�LA', 'MUHASEBE �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (11815, 'MU�LA', 'MU�LA �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7474, 'ARTV�N', 'ERISIM');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (10776, 'ARTV�N', '�ORUH-FTTX');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (9684, 'TEK�RDA�', 'MUHASEBE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (15076, 'ANTALYA', 'GUNEY1 BOLGE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (14567, 'AFYON', 'OPERASYON M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (18501, 'KIBRIS', 'KIBRIS');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7034, 'ADANA', 'CEYHAN');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (2449, 'ADANA', 'MAHFESI�MAZ');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3946, 'ADANA', 'SEYHAN');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4276, 'ADANA', 'Y�RE��R');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6736, 'SAKARYA', 'SAKARYA �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3449, 'ADIYAMAN', '�L M�D�RL�K MERKEZ');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6709, 'AFYON', 'AFYONKARAH�SAR �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3758, 'A�RI', 'A�RI �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3060, 'AKSARAY', 'AKSARAY �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5145, 'AMASYA', 'MERZ�FON');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1331, 'AMASYA', 'YE��LIRMAK');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7897, 'ANKARA', 'BAH�EL�EVLER');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1659, 'ANKARA', 'D�KMEN');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1041, 'ANKARA', '�NCESU');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5383, 'ANKARA', 'KE���REN');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3578, 'ANKARA', 'POLATLI');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8863, 'ANKARA', 'S�NCAN');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1447, 'ANKARA', 'ULUS');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8022, 'ANKARA', 'YEN�MAHALLE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (2784, 'ANKARA', 'YEN��EH�R');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4115, 'ANTALYA', 'ALANYA');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1108, 'ANTALYA', 'G�LL�K');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1164, 'ANTALYA', 'KIZILTOPRAK');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1146, 'ANTALYA', 'MANAVGAT');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (9009, 'ARDAHAN', 'ARDAHAN �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8391, 'ARTV�N', 'ARTV�N');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3496, 'AYDIN', '�AR�I');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (2410, 'AYDIN', 'KU�ADASI');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6920, 'AYDIN', 'NAZ�LL�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7314, 'AYDIN', 'S�KE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4811, 'B�LEC�K', 'B�LEC�K �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5239, 'BALIKES�R', 'ALTI EYL�L M�D.');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8084, 'BALIKES�R', 'BANDIRMA M�D.');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (9017, 'BALIKES�R', 'EDREM�T M�D.');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5137, 'B�NG�L', 'B�NG�L �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (2392, 'D�ZCE', 'D�ZCE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6194, 'BURDUR', '�L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5379, 'BURSA', 'Gen�Osman');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6076, 'BURSA', '�NEG�L');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8789, 'BURSA', 'SETBA�I');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5367, 'BARTIN', 'BARTIN �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (2927, 'B�TL�S', 'KALE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5367, 'BATMAN', 'BATMAN �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3199, 'BAYBURT', 'BAYBURT �L');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5095, '�ANKIRI', 'KARATEK�N M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8869, '�ANAKKALE', 'B�GA');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3516, '�ANAKKALE', '18 MART ');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7764, 'DEN�ZL�', 'ER���M YTR. VE OPERASYON M�D.');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3525, 'D�YARBAKIR', 'BA�LAR');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1250, 'D�YARBAKIR', 'SUR���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4863, 'ELAZI�', 'HARPUT');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8679, 'ERZ�NCAN', 'ERZ�NCAN �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7071, 'ERZURUM', 'DO�U I B�LGE M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1868, 'ESK��EH�R', '�K� EYL�L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6469, 'ESK��EH�R', 'YUNUSEMRE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5712, 'G�M��HANE', 'G�M��HANE �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4680, 'G�RESUN', 'G�RESUN �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1787, 'GAZ�ANTEP', 'N�Z�P');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (2542, 'GAZ�ANTEP', '�AH�NBEY');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8018, 'GAZ�ANTEP', '�EH�T KAM�L');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (2165, 'HAKKAR�', 'HAKKAR� �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5183, 'HATAY', '�SKENDERUN');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5487, 'I�DIR', 'I�DIR �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1308, 'ISPARTA', 'YALVA�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4639, 'ISPARTA', 'HALIKENT');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6251, '�STANBUL AND', 'ERENK�Y');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1778, '�STANBUL AND', 'KADIK�Y');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8669, '�STANBUL AND', 'K���KYALI');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8666, '�STANBUL AND', 'PEND�K');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5826, '�STANBUL AND', '�MRAN�YE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1960, '�STANBUL AND', '�SK�DAR');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7161, '�STANBUL AVR.', 'AVCILAR');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6324, '�STANBUL AVR.', 'BA�CILAR');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5212, '�STANBUL AVR.', 'BAH�EL�EVLER');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (9041, '�STANBUL AVR.', 'BAKIRK�Y');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3669, '�STANBUL AVR.', 'BAYRAMPA�A (ESENLER)');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1450, '�STANBUL AVR.', 'BEBEK');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7159, '�STANBUL AVR.', 'BEYO�LU');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6024, '�STANBUL AVR.', 'B�Y�K�EKMECE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (2662, '�STANBUL AVR.', 'EM�N�N� M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3237, '�STANBUL AVR.', 'FAT�H');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3176, '�STANBUL AVR.', 'GAYRETTEPE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4488, '�STANBUL AVR.', 'GAZ�OSMANPA�A');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3308, '�STANBUL AVR.', 'G�R�NT�L� TELEFON');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8949, '�ZM�R', '�ZM�R BAH�EL�EVLER');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6482, '�ZM�R', '�ZM�R BERGAMA');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1843, '�ZM�R', 'BORNOVA');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6065, '�ZM�R', '�ZM�R SAH�L');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4742, '�ZM�R', '�ZM�R KARABA�LAR');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7728, '�ZM�R', '�ZM�R KAR�IYAKA');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4387, '�ZM�R', '�ZM�R KONAK');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7231, '�ZM�R', '�ZM�R �DEM��');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4960, '�ZM�R', '�ZM�R �E�ME (YARIMADA)');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1840, '�ZM�R', '�ZM�R YEN��EH�R');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3220, 'KOCAEL�', 'ALEMDAR');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8990, 'KOCAEL�', 'GEBZE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8434, 'KOCAEL�', 'G�LC�K');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5856, 'KARS', 'KARS �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8520, 'K�L�S', 'K�L�S');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6242, 'KAHRAMANMARA�', 'ELB�STAN ��LETME UZMANLI�I');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8703, 'KONYA', 'AK�EH�R');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1664, 'KONYA', 'BEY�EH�R');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6550, 'KONYA', 'C�HANBEYL�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1504, 'KONYA', 'ERE�L�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4878, 'KONYA', 'ILGIN(KAPANDI)');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3321, 'KONYA', 'MEVLANA');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7493, 'KONYA', 'SEL�UKLU(KAPANDI)');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7999, 'KARAB�K', '�L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3464, 'KIRIKKALE', 'CUMHUR�YET');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7343, 'KIRKLAREL�', 'KIRKLAREL� �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6885, 'KARAMAN', 'KARAMAN');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3931, 'KIR�EH�R', 'KIR�EH�R �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5999, 'KAYSER�', 'AYDINLIKEVLER');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (2293, 'KAYSER�', 'ERC�YES M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (2080, 'MU�LA', 'BODRUM M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (2630, 'MU�LA', 'FETH�YE M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6293, 'MU�LA', 'MU�LA �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6335, 'MU�LA', 'MARMAR�S M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8342, 'MU�LA', 'M�LAS M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4940, 'MALATYA', 'MALATYA �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5125, 'MAN�SA', 'AKH�SAR');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6858, 'MAN�SA', 'MES�R M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4584, 'MAN�SA', 'SAL�HL�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6623, 'MARD�N', 'D�YARBAKIRKAPI');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4136, 'MERS�N (��EL)', 'MEZ�TL�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7107, 'MERS�N (��EL)', 'S�L�FKE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5713, 'MERS�N (��EL)', 'TARSUS ');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (2021, 'MU�', 'TEK. ��L. VE YAT. M�D.');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8513, 'N��DE', 'YEN�CE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5783, 'NEV�EH�R', 'NEV�EH�R �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6642, 'ORDU', 'FATSA');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6812, 'ORDU', '�NYE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6637, 'ORDU', 'ONDOKUZ EYL�L');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8159, 'OSMAN�YE', 'OSMAN�YE �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3688, 'OSMAN�YE', 'OSMAN�YE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7000, 'R�ZE', 'R�ZE �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6753, 'S��RT', 'S��RT �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1744, 'SAMSUN', 'BAFRA TLK.��L.UZMANLI�I');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7891, 'SAMSUN', '�LKADIM');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8889, 'SAMSUN', 'CAN�K');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8128, 'S�NOP', 'BOYABAT');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3890, 'S�NOP', 'S�NOP �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7612, 'S�VAS', 'S�VAS �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4664, '�IRNAK', '�IRNAK �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5616, '�ANLIURFA', 'S�VEREK');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8245, '�ANLIURFA', 'YEN��EHIR');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6524, 'TEK�RDA�', '�ORLU');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7066, 'TEK�RDA�', 'TEK�RDA� �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8263, 'TOKAT', 'TURHAL');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4304, 'TUNCEL�', 'TUNCEL� �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1909, 'TRABZON', 'KANUN�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6305, 'U�AK', 'KURTULU�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6673, 'VAN', 'VAN �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3790, 'YALOVA', 'YALOVA');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3762, 'YOZGAT', 'YOZGAT �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (7694, 'ZONGULDAK', 'ZONGULDAK �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3184, 'ZONGULDAK', 'KARADEN�Z ERE�L�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (2446, 'BURSA', 'N�L�FER');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4311, 'MERS�N (��EL)', 'TOROSLAR ');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8022, '�ZM�R', '���L�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5053, 'MERS�N (��EL)', 'ERDEML�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5727, 'TRABZON', 'AK�AABAT');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6417, 'ANTALYA', 'KUMLUCA');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1486, 'KIRKLAREL�', 'L�LEBURGAZ');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1845, 'BURSA', 'M.KEMALPA�A');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (2426, '�STANBUL AVR.', '�K�TELL�');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5332, 'KIRKLAREL�', '�PTAL');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (9136, 'ZONGULDAK', 'HUKUK UZM.');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6899, 'GAZ�ANTEP', 'B�LG� ��LEM M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (8572, 'MU�LA', 'MU�LA �L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1768, 'ANKARA', 'B�LG� ��LEM');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (2136, 'ANKARA', 'GEL�RLER TAK�P');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (4719, 'ANKARA', 'MUHASEBE');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3650, 'ANKARA', 'KAMU SATI� M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (6397, 'ANKARA', 'TOPTAN SATI� M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (9045, 'GAZ�ANTEP', 'HUKUK ��LER� M�D');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3030, 'KIR�EH�R', 'HATA');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (3678, 'GAZ�ANTEP', 'MUHASEBE M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (1681, 'MAN�SA', '�L M�D�RL���');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5525, 'ANTALYA', 'ANTALYA');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5295, '�STANBUL(ANADOLU)', '�STANBUL ��Z�M');
Insert into EGITIM.MUDURLUK
   (MUDURLUK_KODU, IL_ADI, MUDURLUK_ADI)
 Values
   (5055, 'ADANA', 'ER���M M�D�RL���');
COMMIT;

SET DEFINE OFF;
Insert into MUDURLUK_HEDEF
   (MUDURLUK_ADI, MUSTERI_SAYISI, MUSTERI_HEDEFI)
 Values
   ('Adana Ceyhan', 180, 200);
Insert into MUDURLUK_HEDEF
   (MUDURLUK_ADI, MUSTERI_SAYISI, MUSTERI_HEDEFI)
 Values
   ('Konya Sel�uklu', 3580, 4000);
Insert into MUDURLUK_HEDEF
   (MUDURLUK_ADI, MUSTERI_SAYISI, MUSTERI_HEDEFI)
 Values
   ('Ankara �ankaya', 7660, 7750);
Insert into MUDURLUK_HEDEF
   (MUDURLUK_ADI, MUSTERI_SAYISI, MUSTERI_HEDEFI)
 Values
   ('�stanbul Ata�ehir', 8650, 8650);
Insert into MUDURLUK_HEDEF
   (MUDURLUK_ADI, MUSTERI_SAYISI, MUSTERI_HEDEFI)
 Values
   ('�zmir Bornova', 565, 600);
Insert into MUDURLUK_HEDEF
   (MUDURLUK_ADI, MUSTERI_SAYISI, MUSTERI_HEDEFI)
 Values
   ('Karab�k Safranbolu', 300, 300);
COMMIT;

SET DEFINE OFF;
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (67, 9, 'Hakkari 9. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (67, 6, 'Hakkari 1116. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (67, 7, 'Hakkari 7. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (67, 8, 'Hakkari 8. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (71, 12, 'Isparta 12. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (71, 15, 'Isparta 15. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (71, 13, 'Isparta 13. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (72, 16, 'Isparta 16. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (135, 18, 'Mersin (��el) 18. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (135, 19, 'Mersin (��el) 19. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (135, 20, 'Mersin (��el) 20. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (3262, 10, 'Hatay 10. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (3263, 11, 'Hatay 11. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (3266, 14, 'Hatay 14. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (3273, 17, 'Isparta 17. �ube');
Insert into MUDURLUK_SUBE
   (MUDURLUK_KODU, SUBE_KODU, SUBE_ADI)
 Values
   (4551, 3, 'Giresun 3. �ube');
COMMIT;

SET DEFINE OFF;
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, PRIM, UNVAN, IZIN_GUNU, YONETICI_ID, DEPT_ID)
 Values
   (5000, 'HAL�L �BRAH�M', 'ERDAL', 2100.45, TO_DATE('08/21/2010 10:15:00', 'MM/DD/YYYY HH24:MI:SS'), '�MRAN�YE', 100, 'M�HEND�S', 13, 919, 112);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, PRIM, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5001, 'SERKAN', 'ALTUNANAHTAR', 2917.13, TO_DATE('05/30/2010 08:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�VE�LER', 125, 'M�HEND�S', 11, 950, 2, 102);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, PRIM, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5002, 'MESUDE', '�ZSER�N', 3529.98, TO_DATE('12/20/2011 15:42:00', 'MM/DD/YYYY HH24:MI:SS'), 'BATIKENT', 250, 'UZMAN', 18, 969, 2, 111);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, PRIM, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5003, 'ERDO�AN', '�ZT�RK', 2822.6, TO_DATE('02/28/2010 18:15:00', 'MM/DD/YYYY HH24:MI:SS'), '�MRAN�YE', 500, 'M�HEND�S', 14, 950, 8, 101);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5004, 'MEHMET', '�AH�N', 3665.61, 'TURAN G�NE�', 'UZMAN', 3, 950, 5, 106);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5005, 'HACEY', 'ARPACI', 6148.92, TO_DATE('04/02/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�UKURAMBAR', '�EF M�HEND�S', 4, 919, 5, 113);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, SEMT, PRIM, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5006, 'AL� YAVUZ', 'KARAMAN', 3280.92, TO_DATE('01/13/2015 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/01/2016 20:06:24', 'MM/DD/YYYY HH24:MI:SS'), 'KADIK�Y', 214, 'TEKN�KER', 8, 919, 6, 104);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, PRIM, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5007, 'AK�F', '�ET�NER', 3153.1, TO_DATE('01/26/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�EKMEK�Y', 622, 'M�HEND�S', 8, 919, 8, 103);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5008, 'VOLKAN', 'KAMALAK', 3692.56, TO_DATE('06/21/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'DEMET', 'M�D�R', 12, 908, 3, 108);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, CIKIS_TARIHI, SEMT, PRIM, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5009, 'ADEM', 'TEM�ZY�REK', 2681.41, TO_DATE('04/17/2016 19:42:07', 'MM/DD/YYYY HH24:MI:SS'), 'SARIYER', 244, 'M�HEND�S', 17, 969, 8, 106);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5010, 'EMRAH �BRAH�M', '�ZT�RK', 2844.17, TO_DATE('02/26/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'UZMAN', 11, 975, 3, 108);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, PRIM, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5011, 'ZAK�NE', 'SAK', 2344.15, TO_DATE('07/26/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�VE�LER', 547, 'M�HEND�S', 9, 975, 4, 114);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, PRIM, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5012, 'EDA', 'PEKCAN', 2266.72, TO_DATE('04/25/2007 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'ACIBADEM', 300, 'M�HEND�S', 2, 975, 4, 105);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, PRIM, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5013, 'SELAMET', 'TA�', 2678.04, TO_DATE('03/15/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'D�KMEN', 200, '�EF M�HEND�S', 5, 919, 1, 104);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, PRIM, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5014, 'MEHMET �NDER', 'BARUT', 3427.33, TO_DATE('12/30/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�ENTEPE', 100, 'TAKIM L�DER�', 10, 998, 1, 109);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5015, 'BENG�', 'KABUKCI', 5178.44, TO_DATE('07/08/2007 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�UKURAMBAR', 'GRUP M�D�R�', 21, 940, 7, 103);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, PRIM, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5016, 'ABDURRAH�M', 'AKINCI', 2524.32, TO_DATE('03/30/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'KE���REN', 200, 'TAKIM L�DER�', 15, 998, 1, 110);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, PRIM, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5017, 'KABR�YE', 'DAL', 3017.22, TO_DATE('08/28/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�EKMEK�Y', 300, '�EF M�HEND�S', 2, 950, 7, 105);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5018, 'G�LPA�A', 'G�ZELTEPE', 2018.42, TO_DATE('08/28/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�ENTEPE', 'M�HEND�S', 8, 998, 1, 114);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5019, 'ABDURRAH�M', 'AKDO�AN', 6558.7, TO_DATE('02/20/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('05/04/2012 20:11:47', 'MM/DD/YYYY HH24:MI:SS'), 'ESENYURT', 'GRUP M�D�R�', 4, 940, 8, 110);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, PRIM, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5020, 'HAN�FE', 'BOYAC�', 3282.97, TO_DATE('10/05/2007 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�UKURAMBAR', 550, 'TEKN�KER', 21, 998, 1, 103);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5021, 'DERYA', 'KARABULUT', 6607.08, TO_DATE('06/30/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'ACIBADEM', 'UZMAN', 1, 919, 1, 103);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5022, 'MEHMET', 'CANLI', 2441.43, TO_DATE('07/16/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'M�HEND�S', 7, 969, 1, 110);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5023, 'FEYZ�', 'AKTEPE', 5669.53, TO_DATE('05/20/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'BATIKENT', '�EF M�HEND�S', 12, 969, 6, 109);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, PRIM, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5025, 'AYSUN', 'UZUNO�LU', 3864.71, TO_DATE('11/16/2007 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�UKURAMBAR', 100, 'M�HEND�S', 16, 975, 9, 102);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5026, '�MER', 'KAVUN', 3961.95, TO_DATE('05/25/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�MRAN�YE', '�EF M�HEND�S', 12, 969, 8, 100);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, SEMT, PRIM, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5027, 'SABR�', 'TA�DELEN', 2745.56, TO_DATE('08/20/2008 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/18/2009 14:47:48', 'MM/DD/YYYY HH24:MI:SS'), 'EY�P', 150, 'TEKN�KER', 7, 940, 5, 108);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5028, 'FAHRETT�N', 'EYUP', 3110.63, TO_DATE('01/30/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/25/2012 20:36:08', 'MM/DD/YYYY HH24:MI:SS'), 'ESENYURT', 'M�D�R', 18, 908, 6, 107);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5029, 'NEV�N', 'YILMAZ', 2246.57, TO_DATE('04/27/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'MEC�D�YEK�Y', 'M�HEND�S', 12, 940, 1, 100);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5030, 'MEHMET AL�', 'T�RKMEN', 4252.02, TO_DATE('10/08/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('03/12/2015 07:11:11', 'MM/DD/YYYY HH24:MI:SS'), 'EY�P', 'UZMAN', 8, 956, 9, 102);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5032, 'AY�E', 'SERT', 2836.61, TO_DATE('02/27/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('11/01/2013 01:35:47', 'MM/DD/YYYY HH24:MI:SS'), 'ERYAMAN', 'UZMAN', 16, 905, 7, 111);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5033, 'AYBARS', 'KO�', 2498.91, TO_DATE('07/11/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'ATA�EH�R', 'M�HEND�S', 9, 913, 5, 114);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5037, 'MEL�KE', 'EM�RO�LU', 2876.5, TO_DATE('04/14/2008 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'SARIYER', 'TAKIM L�DER�', 23, 913, 5, 112);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5038, 'ZEYNEP', 'YAVA�', 4491.43, TO_DATE('09/14/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('06/09/2016 16:11:49', 'MM/DD/YYYY HH24:MI:SS'), '�AYYOLU', 'M�D�R', 17, 928, 6, 106);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5039, '�NDER', 'F�L�Z', 5802.44, TO_DATE('05/06/2008 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�UKURAMBAR', 'UZMAN', 11, 913, 9, 113);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5040, 'EKREM', 'KARAKA�', 4590.77, TO_DATE('09/04/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'MEC�D�YEK�Y', 'M�D�R', 4, 928, 3, 113);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5041, 'ALPASLAN', 'AKAR', 6054.72, TO_DATE('05/11/2007 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'ERYAMAN', 'TAKIM L�DER�', 13, 913, 1, 112);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5043, 'MEHMET AL�', '��L', 3572.93, TO_DATE('12/15/2015 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'ATA�EH�R', 'UZMAN', 8, 913, 6, 101);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5044, '�AH�N', 'G��ER', 2420.3, TO_DATE('04/09/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'KE���REN', 'M�HEND�S', 2, 926, 8, 108);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5045, 'D�LBER', 'ARSLAN', 3456.53, TO_DATE('12/27/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'KE���REN', 'UZMAN', 5, 917, 4, 104);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5047, 'DAVUT', 'BI�AK�I', 3826.57, TO_DATE('06/08/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'BA�CILAR', 'UZMAN', 13, 926, 1, 105);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5048, 'DANYAL', '�EL�K', 4594.34, TO_DATE('09/04/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�UKURAMBAR', 'UZMAN', 6, 926, 1, 109);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5049, 'KENAN', 'FAZ�LO�ULLARI', 1395.21, TO_DATE('07/21/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('01/08/2011 17:00:45', 'MM/DD/YYYY HH24:MI:SS'), 'KADIK�Y', 'TEKN�KER', 14, 926, 2, 109);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5050, 'S�LEYMAN', 'BAYRAKTUTAN', 6340.02, TO_DATE('03/13/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�AYYOLU', 'GRUP M�D�R�', 9, 956, 2, 107);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5051, 'TARKAN', 'KILI�', 2526.31, TO_DATE('07/08/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'BATIKENT', 'M�HEND�S', 5, 917, 6, 114);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5052, 'NESL�HAN', 'YILMAZ', 3136.11, TO_DATE('01/28/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/25/2011 06:58:27', 'MM/DD/YYYY HH24:MI:SS'), 'ERYAMAN', 'UZMAN', 7, 913, 6, 112);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5053, 'HUR� N��AR', '�AHPAZ KUR�UN', 4483.7, TO_DATE('09/15/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('08/01/2011 08:34:14', 'MM/DD/YYYY HH24:MI:SS'), 'ERYAMAN', 'TAKIM L�DER�', 14, 926, 1, 102);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5054, 'D�LEK', 'ALTIPARMAK', 3543.77, TO_DATE('12/18/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'ERYAMAN', 'UZMAN', 6, 905, 4, 112);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5055, '�MER', 'SA�LAMER', 3758.58, TO_DATE('11/27/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'BATIKENT', 'M�HEND�S', 10, 905, 6, 103);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5056, 'B�LENT', 'DURGUN', 4912.01, TO_DATE('08/03/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'DUDULLU', 'M�D�R', 15, 938, 6, 103);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5057, 'FAHRETT�N', '�O�UT', 3991.62, TO_DATE('11/03/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('03/24/2012 12:19:18', 'MM/DD/YYYY HH24:MI:SS'), 'ERYAMAN', 'TAKIM L�DER�', 14, 905, 3, 104);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5059, 'BURCU', 'CIBIR', 2854.76, TO_DATE('02/25/2015 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'DUDULLU', 'UZMAN', 11, 950, 9, 101);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5060, 'SERVET', 'TURAN', 5060.81, TO_DATE('07/19/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�M�TK�Y', 'M�D�R', 11, 940, 9, 100);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5061, 'MUSTAFA', 'KOLAY', 5108.28, TO_DATE('07/15/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'KARTAL', 'M�HEND�S', 11, 905, 6, 102);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5063, 'MUHAMMET', 'AT�EKEN', 4246.94, TO_DATE('10/09/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'ERYAMAN', 'UZMAN', 8, 913, 9, 113);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5064, 'SUNA', 'KAYA', 3739.09, TO_DATE('11/29/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'D�KMEN', 'UZMAN', 5, 913, 4, 112);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5065, 'M�M�NE', 'KAHVEC�', 2126.93, TO_DATE('05/09/2007 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'DEMET', 'M�HEND�S', 8, 913, 7, 107);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5066, 'CEL�L', 'AKG�N', 3377.91, TO_DATE('01/04/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'KE���REN', 'UZMAN', 5, 905, 4, 107);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5067, 'N�L�FER', 'DEM�R', 2983.02, TO_DATE('04/03/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('01/25/2014 22:08:09', 'MM/DD/YYYY HH24:MI:SS'), 'MALTEPE', 'TAKIM L�DER�', 14, 917, 6, 108);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5068, 'SERCAN', 'TOY', 1571.9, TO_DATE('07/03/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'DEMET', 'TEKN�KER', 11, 917, 6, 109);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5069, 'ENSAR', 'Y�KSEK', 6843.71, TO_DATE('01/22/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�M�TK�Y', 'GRUP M�D�R�', 14, 956, 5, 113);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5070, 'MAHMUT', 'YILDIRIM', 4232.28, TO_DATE('10/10/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'TURAN G�NE�', 'TAKIM L�DER�', 9, 917, 7, 113);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5072, 'AL� AYDIN', 'BA�PINAR', 2459.05, TO_DATE('04/06/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'KADIK�Y', 'UZMAN', 16, 917, 4, 106);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5073, 'AYTOP', 'UZUNDAL', 2874.79, TO_DATE('02/23/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'KE���REN', 'M�HEND�S', 14, 908, 2, 102);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5074, 'T�RKAN', 'TURAN', 3020.78, TO_DATE('05/19/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�MRAN�YE', 'TAKIM L�DER�', 16, 908, 9, 108);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5075, 'M�YASE', 'AYAN', 5909.2, TO_DATE('06/26/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�M�TK�Y', 'GRUP M�D�R�', 1, 950, 6, 114);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5077, 'FATMA NEZ�HA', 'SAYIN', 1204.73, TO_DATE('08/09/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'D�KMEN', 'TEKN�KER', 13, 928, 5, 113);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5078, '�SMA�L', 'G�LEN', 2362.5, TO_DATE('07/29/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('04/22/2014 20:11:31', 'MM/DD/YYYY HH24:MI:SS'), 'DEMET', 'UZMAN YARDIMCISI', 10, 956, 4, 112);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5079, 'NURETT�N', 'PEHL�VAN', 1993.72, TO_DATE('05/22/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('05/05/2015 19:17:42', 'MM/DD/YYYY HH24:MI:SS'), 'D�KMEN', 'TEKN�KER', 14, 928, 8, 113);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5080, 'NURHAN', 'BORA', 4760.24, TO_DATE('08/18/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'MALTEPE', 'M�HEND�S', 13, 938, 1, 109);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5081, 'MAHMUT', 'G�LER', 1766.08, TO_DATE('06/14/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'KADIK�Y', 'TEKN�KER', 2, 938, 2, 104);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5082, 'Z�YA', '�OBANO�LU', 2070.13, TO_DATE('05/14/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'KARTAL', 'TEKN�KER', 11, 950, 7, 104);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5083, 'MURAT', 'D�NG�L', 2361.85, TO_DATE('04/15/2008 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'DEMET', 'UZMAN', 7, 905, 1, 101);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5084, 'SERVET', 'TURAN', 5060.81, TO_DATE('07/19/2007 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'BA�CILAR', 'M�D�R', 5, 956, 9, 109);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5085, 'H�SEY�N TU�SAN', 'BALLI', 2345.9, TO_DATE('04/17/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'D�KMEN', 'M�HEND�S', 8, 938, 3, 112);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5086, 'MEHMET FAT�H', 'KAPLAN', 1919, TO_DATE('05/30/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'D�KMEN', 'TEKN�KER', 3, 938, 6, 107);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5088, 'MEHMET �EF�K', 'TEYMURO�LU', 2262.47, TO_DATE('07/29/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'ERYAMAN', 'TEKN�KER', 11, 938, 8, 105);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5089, 'BAHADIR', '�AH�N', 2173.36, TO_DATE('05/04/2015 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'BATIKENT', 'M�HEND�S', 13, 905, 8, 100);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5090, 'FAT�H', 'YILMAZ', 1479.42, TO_DATE('07/13/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'DEMET', 'TEKN�KER', 14, 940, 2, 100);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5091, 'VEY�S', 'ATMACA', 3560.23, TO_DATE('07/04/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'KADIK�Y', '�EF M�HEND�S', 6, 975, 8, 110);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5092, 'AYDIN', 'EVREN', 1637.21, TO_DATE('06/27/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'KADIK�Y', 'TEKN�KER', 6, 938, 5, 107);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5093, 'BANU', 'DEM�RO�LU', 1752.55, TO_DATE('08/27/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('01/10/2013 05:46:35', 'MM/DD/YYYY HH24:MI:SS'), 'UZMAN YARDIMCISI', 1, 908, 3, 109);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5094, 'YAS�N', '�ZDA�', 3462.62, TO_DATE('07/14/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('03/16/2017 17:38:55', 'MM/DD/YYYY HH24:MI:SS'), 'KE���REN', 'TAKIM L�DER�', 11, 998, 2, 104);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, CIKIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5095, 'AHMET EM�N', 'OKUYUCU', 3952.92, TO_DATE('11/07/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('01/11/2017 10:48:55', 'MM/DD/YYYY HH24:MI:SS'), '�M�TK�Y', 'TAKIM L�DER�', 4, 928, 2, 114);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5096, 'SERDAR', 'BOZKURT', 2881.69, TO_DATE('02/22/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'BATIKENT', 'TAKIM L�DER�', 18, 940, 8, 109);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5097, 'AL� SEL�UK', 'BE�G�L', 4982.65, TO_DATE('05/23/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'DEMET', 'M�D�R', 7, 956, 4, 113);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5098, '�ZCAN', 'KIZILTEPE', 6308.84, TO_DATE('03/17/2008 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '�UKURAMBAR', 'GRUP M�D�R�', 20, 919, 2, 104);
Insert into PERSONEL
   (PERSONEL_ID, AD, SOYAD, MAAS, GIRIS_TARIHI, SEMT, UNVAN, IZIN_GUNU, YONETICI_ID, KONUM_ID, DEPT_ID)
 Values
   (5099, 'RECEP', 'ARI', 5947.95, TO_DATE('04/22/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'BATIKENT', '�EF M�HEND�S', 5, 975, 4, 104);
COMMIT;

SET DEFINE OFF;
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5092, 7, TO_DATE('08/18/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('08/23/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5053, 9, TO_DATE('02/04/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('02/07/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5060, 3, TO_DATE('11/26/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('11/30/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5026, 8, TO_DATE('05/28/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('05/30/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5017, 6, TO_DATE('09/11/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/13/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5080, 9, TO_DATE('12/18/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/20/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5059, 9, TO_DATE('03/27/2016 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('03/28/2016 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI, IZIN_BAS_SAATI, IZIN_BIT_SAATI)
 Values
   (5006, 2, TO_DATE('02/23/2016 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('02/25/2016 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '13:00:00', '15:00:00');
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI, IZIN_BAS_SAATI, IZIN_BIT_SAATI)
 Values
   (5049, 2, TO_DATE('12/27/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '10:00:00', '13:00:00');
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5073, 4, TO_DATE('04/13/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('04/17/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5082, 6, TO_DATE('10/31/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('11/04/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5015, 7, TO_DATE('11/30/2008 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/03/2008 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5018, 1, TO_DATE('01/25/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('01/28/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5044, 4, TO_DATE('08/16/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('08/19/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5029, 7, TO_DATE('05/26/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('05/29/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5075, 8, TO_DATE('08/21/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('08/23/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5063, 4, TO_DATE('12/17/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/21/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5016, 1, TO_DATE('09/05/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/09/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5091, 4, TO_DATE('12/11/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/12/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5002, 5, TO_DATE('12/21/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/25/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5007, 9, TO_DATE('02/21/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('02/26/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI, IZIN_BAS_SAATI, IZIN_BIT_SAATI)
 Values
   (5056, 2, TO_DATE('09/07/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/09/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '11:00:00', '12:00:00');
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5049, 3, TO_DATE('07/29/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('08/03/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5010, 10, TO_DATE('08/08/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('08/11/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5025, 10, TO_DATE('11/22/2008 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('11/23/2008 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5094, 1, TO_DATE('08/21/2015 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('08/22/2015 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5002, 4, TO_DATE('02/17/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('02/19/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5032, 1, TO_DATE('03/03/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('03/06/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5027, 1, TO_DATE('02/04/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('02/07/2010 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI, IZIN_BAS_SAATI, IZIN_BIT_SAATI)
 Values
   (5022, 2, TO_DATE('09/17/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/21/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '11:00:00', '12:00:00');
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5083, 7, TO_DATE('04/27/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('04/29/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5037, 1, TO_DATE('08/17/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('08/18/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5000, 3, TO_DATE('11/12/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('11/16/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5090, 5, TO_DATE('12/06/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/09/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI, IZIN_BAS_SAATI, IZIN_BIT_SAATI)
 Values
   (5055, 2, TO_DATE('04/16/2016 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('04/19/2016 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '12:00:00', '16:00:00');
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5049, 3, TO_DATE('10/17/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('10/22/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5073, 9, TO_DATE('06/13/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('06/15/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5017, 7, TO_DATE('10/18/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('10/23/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5010, 4, TO_DATE('05/07/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('05/09/2011 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5082, 4, TO_DATE('05/29/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('06/02/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into PERSONEL_IZINLERI
   (PERSONEL_ID, IZIN_TURU, IZIN_BAS_TARIHI, IZIN_BIT_TARIHI)
 Values
   (5027, 4, TO_DATE('08/27/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('08/30/2009 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
COMMIT;

SET DEFINE OFF;
Insert into UCRET_DUZEY
   (DERECE, MAAS_ALT_LIMIT, MAAS_UST_LIMIT, ACIKLAMA)
 Values
   (1, 1000, 2000, '�ok D���k �cret');
Insert into UCRET_DUZEY
   (DERECE, MAAS_ALT_LIMIT, MAAS_UST_LIMIT, ACIKLAMA)
 Values
   (2, 2001, 3000, 'D���k �cret');
Insert into UCRET_DUZEY
   (DERECE, MAAS_ALT_LIMIT, MAAS_UST_LIMIT, ACIKLAMA)
 Values
   (3, 3001, 5000, 'Orta �cret');
Insert into UCRET_DUZEY
   (DERECE, MAAS_ALT_LIMIT, MAAS_UST_LIMIT, ACIKLAMA)
 Values
   (4, 5001, 8000, 'Y�ksek �cret');
Insert into UCRET_DUZEY
   (DERECE, MAAS_ALT_LIMIT, MAAS_UST_LIMIT, ACIKLAMA)
 Values
   (5, 8001, 20000, '�ok Y�ksek �cret');
COMMIT;

SET DEFINE OFF;
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (905, 5005, 3);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (908, 5008, 1);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (913, 5013, 3);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (917, 5017, 3);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (919, 5019, 2);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (923, 5023, 3);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (926, 5026, 3);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (928, 5028, 1);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (938, 5038, 1);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (940, 5040, 1);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (950, 5050, 2);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (956, 5056, 1);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (969, 5069, 2);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (975, 5075, 2);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (998, 5098, 2);
COMMIT;

