SET DEFINE OFF;
Insert into BOLGELER
   (BOLGE_KODU, BOLGE_ADI)
 Values
   (1, '�� ANADOLU');
Insert into BOLGELER
   (BOLGE_KODU, BOLGE_ADI)
 Values
   (2, 'MARMARA');
Insert into BOLGELER
   (BOLGE_KODU, BOLGE_ADI)
 Values
   (3, 'EGE');
Insert into BOLGELER
   (BOLGE_KODU, BOLGE_ADI)
 Values
   (4, 'AKDEN�Z');
Insert into BOLGELER
   (BOLGE_KODU, BOLGE_ADI)
 Values
   (5, 'DO�U ANADALU');
Insert into BOLGELER
   (BOLGE_KODU, BOLGE_ADI)
 Values
   (6, 'G�NEY DO�U ANADOLU');
Insert into BOLGELER
   (BOLGE_KODU, BOLGE_ADI)
 Values
   (7, 'KARADEN�Z');
COMMIT;
