SET DEFINE OFF;
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (905, 5005, 3);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (908, 5008, 1);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (913, 5013, 3);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (917, 5017, 3);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (919, 5019, 2);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (923, 5023, 3);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (926, 5026, 3);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (928, 5028, 1);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (938, 5038, 1);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (940, 5040, 1);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (950, 5050, 2);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (956, 5056, 1);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (969, 5069, 2);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (975, 5075, 2);
Insert into YONETICI
   (YONETICI_ID, PERSONEL_ID, SEVIYE)
 Values
   (998, 5098, 2);
COMMIT;
