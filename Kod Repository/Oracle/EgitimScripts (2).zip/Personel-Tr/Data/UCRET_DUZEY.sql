SET DEFINE OFF;
Insert into UCRET_DUZEY
   (DERECE, MAAS_ALT_LIMIT, MAAS_UST_LIMIT, ACIKLAMA)
 Values
   (1, 1000, 2000, '�ok D���k �cret');
Insert into UCRET_DUZEY
   (DERECE, MAAS_ALT_LIMIT, MAAS_UST_LIMIT, ACIKLAMA)
 Values
   (2, 2001, 3000, 'D���k �cret');
Insert into UCRET_DUZEY
   (DERECE, MAAS_ALT_LIMIT, MAAS_UST_LIMIT, ACIKLAMA)
 Values
   (3, 3001, 5000, 'Orta �cret');
Insert into UCRET_DUZEY
   (DERECE, MAAS_ALT_LIMIT, MAAS_UST_LIMIT, ACIKLAMA)
 Values
   (4, 5001, 8000, 'Y�ksek �cret');
Insert into UCRET_DUZEY
   (DERECE, MAAS_ALT_LIMIT, MAAS_UST_LIMIT, ACIKLAMA)
 Values
   (5, 8001, 20000, '�ok Y�ksek �cret');
COMMIT;
