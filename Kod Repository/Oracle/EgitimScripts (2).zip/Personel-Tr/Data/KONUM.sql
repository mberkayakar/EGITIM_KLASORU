SET DEFINE OFF;
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (1, 'Ankara - Ayd�nl�kevler', 6);
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (2, 'Ankara - TOBB Yerle�kesi', 6);
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (3, 'Ankara - Akademi E�itim Birimi', 6);
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (4, 'Akara - �l M�d�rl���', 6);
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (5, '�stanbul - �mraniye', 34);
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (6, '�stanbul - Ac�badem', 34);
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (7, '�stanbul - Gayrettepe', 34);
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (8, 'Trabzon - Ma�ka', 61);
Insert into KONUM
   (KONUM_ID, KONUM_ADI, IL_KODU)
 Values
   (9, 'Konya - Sel�uklu', 42);
COMMIT;
